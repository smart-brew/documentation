---
sidebar_position: 1
title: Zápisnica template
---

:::tip TODO
Pri vypĺňaní template je potreba prepísať hore v hlavičke atribút **title** do formátu: **DD.MM.YYYY** _(napr. 04.10.2021)_.
A sidebar*position na najnižšie číslo zo zápisníc *(napr. predošlá má číslo 3, tak moja bude mať číslo 4)\_.
:::

# Zápisnica - DD.MM.YYYY

## Zhrnutie taskov

_Zhrnutie, kto je ako na tom so svojimi taskami, ako progressujú stories a podobne. Stačí v odrážkach._

## Prezentácia vypracovaných taskov

_Pokiaľ niekto mal task ako analýzu, alebo je to niečo, čo potrebuje celý tím odsúhlasiť._

## Identifikácia nových problémov

_S čím sme mali pri vypracovávaní taskov problém a aké nové issues vznikli._

## Vytvorenie nových stories/taskov

_Aké nové tasky vznikli a komu boli priradené._

### Stories

_Novovzniknuté stories._

### Tasky

_Novovzniknuté tasky._

## Diskusia

_Iné témy, ktoré sa prebrali na stretnutí._
