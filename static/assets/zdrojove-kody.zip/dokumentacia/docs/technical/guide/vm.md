---
author: Peter Stríž
---

# Tímová VM

```bash title="SSH"
ssh -i path/to/key ubuntu@team06-21.studenti.fiit.stuba.sk
```

## Údaje od SSH pripojenia

```bash title="Adresa"
team06-21.studenti.fiit.stuba.sk
```

```bash title="Username"
ubuntu
```

```bash title="Key (ukážka)"
-----BEGIN RSA PRIVATE KEY-----
MIIEpA*************************
*******************************
***********************8+1y9A==
-----END RSA PRIVATE KEY-----
```
