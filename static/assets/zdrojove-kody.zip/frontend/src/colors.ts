// TODO: toto nejako spravit aby to bolo v tailwind ako custom farba, ale nevedel som ako na to - PETO
export const DARK_YELLOW = '#c5a103';
