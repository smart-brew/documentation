import React from 'react';

const HistoryPage: React.FC = () => {
  return <div>History page</div>;
};
export default HistoryPage;
