interface ParamType {
  optionCodeName: string | null;
  value: number | string | null;
}

export default ParamType;
