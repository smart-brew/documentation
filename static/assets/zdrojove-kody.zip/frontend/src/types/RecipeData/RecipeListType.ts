import RecipeType from './RecipeType';

type RecipeListType = {
  recipes: Array<RecipeType>;
};

export default RecipeListType;
