import ParamType from '../ParamType';

type EditableInstrRefType = {
  readParams: () => ParamType | null;
};

export default EditableInstrRefType;
