type InstructionState = {
  codeName: string;
  name: string;
  style: string | null;
};

export default InstructionState;
