type DeviceType = {
  id: number;
  name: string;
  device: string;
};

export default DeviceType;
