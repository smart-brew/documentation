/* eslint-disable camelcase */

type OptionType = {
  id: number;
  name: string;
  codeName: string;
};

export default OptionType;
