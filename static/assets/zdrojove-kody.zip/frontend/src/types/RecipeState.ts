/* eslint-disable camelcase */

import ChambersInfo from './ChamberInfo';

type RecipeState = {
  module_states: Array<ChambersInfo>;
  // and others
};

export default RecipeState;
