# Startup

Only Docker compose needed

## Windows

```bash
startup.bat
```

## Linux

```bash
sh startup.sh
```
