-- AlterTable
ALTER TABLE "Instruction_logs" ALTER COLUMN "instruction_id" DROP NOT NULL;
