-- AlterTable
ALTER TABLE "Function_templates" ALTER COLUMN "input_type" DROP NOT NULL,
ALTER COLUMN "units" DROP NOT NULL;
