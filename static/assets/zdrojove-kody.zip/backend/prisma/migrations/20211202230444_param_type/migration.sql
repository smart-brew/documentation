-- AlterTable
ALTER TABLE "Instructions" ALTER COLUMN "param" SET DATA TYPE VARCHAR;
