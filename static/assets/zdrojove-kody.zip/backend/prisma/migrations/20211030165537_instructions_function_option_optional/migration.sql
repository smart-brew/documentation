-- AlterTable
ALTER TABLE "Instructions" ALTER COLUMN "function_option_id" DROP NOT NULL;
