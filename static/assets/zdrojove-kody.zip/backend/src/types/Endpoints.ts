export interface StartBrewBody {
  recipeId: number;
}
